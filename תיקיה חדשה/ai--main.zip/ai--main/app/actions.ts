'use server';

import { GoogleGenAI, Type } from '@google/genai';
import { getDb, saveDb, PredictionRecord } from '@/lib/db';

export async function analyzeCrypto(symbol: string) {
  try {
    const cleanSymbol = symbol.toUpperCase().replace(/[^A-Z0-9]/g, '');

    // 1. Fetch Binance Data (OHLCV) - 30 days for chart
    const binanceRes = await fetch(`https://api.binance.com/api/v3/klines?symbol=${cleanSymbol}&interval=1d&limit=30`);
    if (!binanceRes.ok) throw new Error(`Failed to fetch Binance data for ${cleanSymbol}. Ensure the symbol is correct (e.g., BTCUSDT).`);
    const binanceData = await binanceRes.json();

    const ohlcv = binanceData.map((k: any) => ({
      date: new Date(k[0]).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      open: parseFloat(k[1]),
      high: parseFloat(k[2]),
      low: parseFloat(k[3]),
      close: parseFloat(k[4]),
      volume: parseFloat(k[5])
    }));
    const currentPrice = ohlcv[ohlcv.length - 1].close;
    const last5Days = ohlcv.slice(-5);

    // 2. Fetch Fear & Greed Index
    let fng = { value: "50", value_classification: "Neutral" };
    try {
      const fngRes = await fetch('https://api.alternative.me/fng/?limit=1');
      const fngData = await fngRes.json();
      if (fngData && fngData.data && fngData.data.length > 0) {
        fng = fngData.data[0];
      }
    } catch (e) {
      console.warn("Could not fetch Fear & Greed index, using default.");
    }

    // 3. Get Past Errors (Learning Loop)
    const db = getDb();
    const pastErrors = db
      .filter(p => p.symbol === cleanSymbol && p.status === 'evaluated' && p.error_report)
      .slice(-5)
      .map(p => ({
        date: p.prediction_date,
        prediction: p.predicted_direction,
        actual: p.actual_outcome,
        learning_note: p.error_report
      }));

    // 4. Call Gemini AI
    const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.includes('TODO')) {
      throw new Error("Gemini API Key is missing or invalid. Please configure your actual API key in the AI Studio Settings (Secrets panel).");
    }
    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = "אתה אנליסט קריפטו מומחה בעל יכולות סטטיסטיות. תפקידך לנתח נתוני שוק ולזהות דפוסי פריצה (Breakout). עליך להתעלם מרעשים ולחפש רק הצטלבויות של נפח מסחר גבוה עם סנטימנט חיובי. פלוט את התחזית בפורמט JSON בלבד. חובה לכלול המלצות אסטרטגיות (strategic_advice), הקשר למידה מהעבר (learning_context) ומקורות מידע (sources).";

    const promptData = {
      asset: cleanSymbol,
      current_price: currentPrice,
      ohlcv_last_5_days: last5Days,
      fear_and_greed_index: fng,
      past_mistakes_to_learn_from: pastErrors
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: JSON.stringify(promptData, null, 2),
      config: {
        systemInstruction,
        temperature: 0.2,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            symbol: { type: Type.STRING },
            probability: { type: Type.INTEGER, description: "0-100" },
            target_percentage: { type: Type.NUMBER, description: "Expected % move" },
            direction: { type: Type.STRING, enum: ["Bullish", "Bearish", "Neutral"] },
            logic: { type: Type.STRING, description: "Explanation based on volume and sentiment" },
            strategic_advice: { type: Type.STRING, description: "Actionable investment advice for this specific asset (in Hebrew)" },
            learning_context: { type: Type.STRING, description: "How past predictions influenced this specific forecast (in Hebrew)" },
            sources: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of data sources used (e.g., Binance OHLCV, Fear & Greed, Historical DB)" }
          },
          required: ["symbol", "probability", "target_percentage", "direction", "logic", "strategic_advice", "learning_context", "sources"]
        }
      }
    });

    if (!response.text) throw new Error("No response from AI");
    const result = JSON.parse(response.text);

    // 5. Save to DB
    const newRecord: PredictionRecord = {
      id: Date.now().toString(),
      symbol: cleanSymbol,
      prediction_date: new Date().toISOString(),
      predicted_direction: result.direction,
      probability: result.probability,
      target_percentage: result.target_percentage,
      entry_price: currentPrice,
      logic: result.logic,
      strategic_advice: result.strategic_advice,
      learning_context: result.learning_context,
      sources: result.sources,
      status: 'pending'
    };

    db.push(newRecord);
    saveDb(db);

    return { success: true, data: newRecord, chartData: ohlcv };
  } catch (error: any) {
    console.error(error);
    return { success: false, error: error.message };
  }
}

export async function getHistory() {
  return getDb().sort((a, b) => new Date(b.prediction_date).getTime() - new Date(a.prediction_date).getTime());
}

export async function evaluatePendingPredictions() {
  const db = getDb();
  let updatedCount = 0;

  const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.includes('TODO')) {
    return { success: false, error: "Gemini API Key is missing or invalid." };
  }
  const ai = new GoogleGenAI({ apiKey });

  for (let i = 0; i < db.length; i++) {
    const record = db[i];
    if (record.status === 'pending') {
      try {
        const binanceRes = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${record.symbol}`);
        if (!binanceRes.ok) continue;
        const binanceData = await binanceRes.json();
        const currentPrice = parseFloat(binanceData.price);

        const priceDiff = ((currentPrice - record.entry_price) / record.entry_price) * 100;

        let isCorrect = false;
        if (record.predicted_direction === 'Bullish' && priceDiff > 0) isCorrect = true;
        if (record.predicted_direction === 'Bearish' && priceDiff < 0) isCorrect = true;
        if (record.predicted_direction === 'Neutral' && Math.abs(priceDiff) < 1) isCorrect = true;

        record.actual_outcome = `Price moved by ${priceDiff.toFixed(2)}% to $${currentPrice}`;

        if (!isCorrect) {
          const prompt = `
          You made a wrong prediction.
          Symbol: ${record.symbol}
          Your Prediction: ${record.predicted_direction}
          Entry Price: $${record.entry_price}
          Actual Current Price: $${currentPrice} (${priceDiff.toFixed(2)}% move)
          Your Logic was: ${record.logic}

          Analyze why this prediction failed. Provide a short, actionable learning note (1-2 sentences in Hebrew) to avoid this mistake next time.
          `;

          const response = await ai.models.generateContent({
            model: 'gemini-3.1-pro-preview',
            contents: prompt,
            config: { temperature: 0.2 }
          });

          record.error_report = response.text || "Failed to generate learning note.";
        } else {
          record.error_report = "התחזית הייתה נכונה. הדפוס אומת בהצלחה.";
        }

        record.status = 'evaluated';
        updatedCount++;
      } catch (e) {
        console.error("Failed to evaluate", record.symbol, e);
      }
    }
  }

  if (updatedCount > 0) {
    saveDb(db);
  }

  return { success: true, updatedCount };
}
