'use client';

import { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface TickerData {
  symbol: string;
  price: number;
  change: number;
}

const TARGET_SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT', 'DOTUSDT'];

export default function CryptoTicker() {
  const [tickers, setTickers] = useState<TickerData[]>([]);

  useEffect(() => {
    const ws = new WebSocket('wss://stream.binance.com:9443/ws/!miniTicker@arr');

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      const filtered = data.filter((t: any) => TARGET_SYMBOLS.includes(t.s));
      
      if (filtered.length > 0) {
        setTickers(prev => {
          const newTickers = [...prev];
          filtered.forEach((f: any) => {
            const price = parseFloat(f.c);
            const open = parseFloat(f.o);
            const change = ((price - open) / open) * 100;
            
            const idx = newTickers.findIndex(t => t.symbol === f.s);
            if (idx >= 0) {
              newTickers[idx] = { symbol: f.s.replace('USDT', ''), price, change };
            } else {
              newTickers.push({ symbol: f.s.replace('USDT', ''), price, change });
            }
          });
          return newTickers;
        });
      }
    };

    return () => ws.close();
  }, []);

  if (tickers.length === 0) return null;

  // Duplicate for seamless scroll
  const displayTickers = [...tickers, ...tickers];

  return (
    <div className="w-full bg-slate-900 border-b border-slate-800 overflow-hidden py-2" id="crypto-ticker">
      <div className="ticker-track">
        {displayTickers.map((ticker, i) => (
          <div key={`${ticker.symbol}-${i}`} className="flex items-center gap-2 px-6 border-r border-slate-800 last:border-0 whitespace-nowrap">
            <span className="font-bold text-slate-300 text-sm">{ticker.symbol}</span>
            <span className="font-mono text-white text-sm">${ticker.price >= 10 ? ticker.price.toFixed(2) : ticker.price.toFixed(4)}</span>
            <span className={`flex items-center text-xs font-semibold ${ticker.change >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
              {ticker.change >= 0 ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
              {Math.abs(ticker.change).toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
