import fs from 'fs';
import path from 'path';

const dbPath = path.join(process.cwd(), 'predictions.json');

export interface PredictionRecord {
  id: string;
  symbol: string;
  prediction_date: string;
  predicted_direction: 'Bullish' | 'Bearish' | 'Neutral';
  probability: number;
  target_percentage: number;
  entry_price: number;
  logic: string;
  strategic_advice?: string;
  learning_context?: string;
  sources?: string[];
  status: 'pending' | 'evaluated';
  actual_outcome?: string;
  error_report?: string;
}

export function getDb(): PredictionRecord[] {
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify([]));
  }
  try {
    const data = fs.readFileSync(dbPath, 'utf-8');
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
}

export function saveDb(data: PredictionRecord[]) {
  fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
}
